#!/usr/bin/python
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import glob
import subprocess
import time


fasta_file = glob.glob('*.fasta')



list_id = []
for seq in SeqIO.parse(fasta_file[0], 'fasta'):
	record = seq.id.split('_')[0:4]
	record = '_'.join(record)
	list_id.append(record)

for name in list_id:
	out = open(name + ".fa", "w")
out.close()

for files in fasta_file:
	print files
	fileid = files.split('.')[1]
	for seq1 in SeqIO.parse(files, 'fasta'):
		dna_seq = str(seq1.seq)
		newname1 = seq1.id.split('_')[0:4]
		newname2 = newname1[0] + "_" + newname1[2] + "_" + newname1[3]
		new_record = SeqRecord(Seq(dna_seq), id=newname2, description='')
		marker_name_file = "../../1_gene_matrix/" + newname1[2] + '.fa'
		with open(marker_name_file, 'a') as fileout:
			SeqIO.write(new_record, fileout, "fasta")
		fileout.close()

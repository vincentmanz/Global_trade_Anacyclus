#!/usr/bin/env python
import glob
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import os
from Bio import AlignIO
import pandas as pd
import numpy as np

z = {}
df = pd.DataFrame()

listfile = glob.glob("*.fasta")
#		listfile = listfile[0:50]
a = len(listfile)
empty_matrix = []
length_matrices = []
missing_data = []
print "Length for each idividual alignment (bp):\n"

for matrix in listfile:
	d = {}
	indexd = matrix.split('.')[0]
	align = AlignIO.read(matrix, 'fasta')
	number_seq = len(align)
	length = align.get_alignment_length()
	length_matrices.append(length)
	marker_name = matrix.split(".")[0]
	if length == 0:
		empty_matrix.append(matrix)
		print marker_name + ": " + str(length)
		continue
	else:
		list_ID = []
		for record in align:
			recordid = record.id.split('_')
			del(recordid[-1])
			recordid = '_'.join(recordid)
			if recordid not in list_ID:
				list_ID.append(recordid)

		for sample in list_ID:
			nCount_0 = 0
			nCount_1 = 0
			n=0
			for record in align:
				sample_0 = sample + "_" + str(0)
				sample_1 = sample + "_" + str(1)
				if sample_0 == record.id:
					n=n+1
					recordSEQ = record.seq
					nCount_0 = (recordSEQ.lower().count('-'))/(len(record.seq)+ 0.0)
				if sample_1 == record.id:
					n=n+1
					recordSEQ = record.seq
					nCount_1 = (recordSEQ.lower().count('-'))/(len(record.seq)+ 0.0)
			ratio = (nCount_0 + nCount_1)/n
			missing_data.append(ratio)
			d[sample] = ratio
		print marker_name + ": " + str(length)


	df1 = pd.DataFrame([d], index=[indexd])

	df = pd.concat([df,df1], axis=0)
	df = df.fillna(1)


	z = {x: d.get(x, 0) + z.get(x, 0) for x in set(d).union(z)}

#save matrix in cv for heatmaps:
df.to_csv("missing_data.csv", sep='\t')

#print markers and sample general stats

print "\nPercentage of missing data per sample"
df_mean_per_markers = df.mean(1)
df_mean_per_samples = df.mean(0)

print df_mean_per_samples
print df_mean_per_markers
df_mean_per_samples.to_csv("mean_per_samples.csv", sep='\t')
df_mean_per_markers.to_csv("mean_per_markers.csv", sep='\t')






# for key, value in z.items():
# 	z[key] = float(format(value/a, '.4f'))
# for kv in (sorted(z.items(), key=lambda x:x[1])):
# 	print kv[0],'\t',kv[1]

print "\nAverage marker length: " + str(np.mean(length_matrices)) + "bp"
print "Total marker length    : " + str(np.sum(length_matrices)) + "bp"
print "\nAverage missing data : " + str(np.mean(missing_data)) + "%"


if len(empty_matrix) == 0:
	print "\nThere is no empty matrices."
else:
	print "\nList of empty matrices:"
	for mat in empty_matrix:
		print mat